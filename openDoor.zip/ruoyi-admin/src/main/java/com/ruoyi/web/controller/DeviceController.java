package com.ruoyi.web.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class DeviceController {

    @PostMapping("/receiveData")
    public String receiveData(@RequestBody String data) {
        // 处理主板发送的数据
        // Process the data sent by the motherboard
        System.out.println("Received data from device: " + data);
        return "Data received successfully";
    }
}
