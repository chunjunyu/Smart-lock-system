package com.ruoyi.web.controller.door;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.door.domain.DoorOpenFingerprint;
import com.ruoyi.door.service.DoorLockService;
import com.ruoyi.door.service.IDoorOpenFingerprintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import java.util.Map;

/**
 * 指纹开锁Controller
 * Fingerprint Unlock Controller
 */
@RestController
@RequestMapping("/door/fingerprint")
public class DoorOpenFingerprintController extends BaseController
{
    @Autowired
    private IDoorOpenFingerprintService doorOpenFingerprintService;

    /**
     * 查询指纹开锁列表
     * Check Fingerprint Unlocking List
     */
//    @PreAuthorize("@ss.hasPermi('door:fingerprint:list')")
    @GetMapping("/list")
    public TableDataInfo list(DoorOpenFingerprint doorOpenFingerprint)
    {
        startPage();
        List<DoorOpenFingerprint> list = doorOpenFingerprintService.selectDoorOpenFingerprintList(doorOpenFingerprint);
        return getDataTable(list);
    }

    /**
     * 导出指纹开锁列表
     * Export Fingerprint Unlock List
     */
//    @PreAuthorize("@ss.hasPermi('door:fingerprint:export')")
    @Log(title = "指纹开锁", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, DoorOpenFingerprint doorOpenFingerprint)
    {
        List<DoorOpenFingerprint> list = doorOpenFingerprintService.selectDoorOpenFingerprintList(doorOpenFingerprint);
        ExcelUtil<DoorOpenFingerprint> util = new ExcelUtil<DoorOpenFingerprint>(DoorOpenFingerprint.class);
        util.exportExcel(response, list, "指纹开锁数据");
    }

    /**
     * 获取指纹开锁详细信息
     * Get Fingerprint Unlocking Details
     */
//    @PreAuthorize("@ss.hasPermi('door:fingerprint:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(doorOpenFingerprintService.selectDoorOpenFingerprintById(id));
    }

    /**
     * Add Fingerprint Unlocking
     */
//    @PreAuthorize("@ss.hasPermi('door:fingerprint:add')")
    @Log(title = "指纹开锁", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody DoorOpenFingerprint doorOpenFingerprint)
    {
        return doorOpenFingerprintService.insertDoorOpenFingerprint(doorOpenFingerprint);
    }

    /**
     * 修改指纹开锁
     * Modify Fingerprint Unlocking
     */
//    @PreAuthorize("@ss.hasPermi('door:fingerprint:edit')")
    @Log(title = "指纹开锁", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody DoorOpenFingerprint doorOpenFingerprint)
    {
        return toAjax(doorOpenFingerprintService.updateDoorOpenFingerprint(doorOpenFingerprint));
    }

    /**
     * 删除指纹开锁
     * Delete Fingerprint Unlocking
     */
//    @PreAuthorize("@ss.hasPermi('door:fingerprint:remove')")
    @Log(title = "指纹开锁", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(doorOpenFingerprintService.deleteDoorOpenFingerprintByIds(ids));
    }



        @PostMapping("/prod-api/door/fingerprint/getOne")
        @ResponseBody
        public String handleFingerprintRequest(@RequestBody String pass) {

            DoorOpenFingerprint doorOpenFingerprint = null;
            doorOpenFingerprint.setPass(pass);
            List<DoorOpenFingerprint> list = doorOpenFingerprintService.selectDoorOpenFingerprintList(doorOpenFingerprint);

            if (list.isEmpty()){
                return "Failed to unlock";
            }else
            {
                return "Successful unlocking.";
            }
    }

}
