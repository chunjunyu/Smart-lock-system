package com.ruoyi.web.controller.door;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.door.service.DoorLockOpenLogService;
import com.ruoyi.door.service.DoorLockService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("/door/lock/open/log")
public class DoorLockOpenLogController extends BaseController {

    @Resource
    private DoorLockOpenLogService doorLockOpenLogService;

    @GetMapping("/list")
    public TableDataInfo list(){
        startPage();
        return getDataTable(doorLockOpenLogService.getAllLog());
    }
}
