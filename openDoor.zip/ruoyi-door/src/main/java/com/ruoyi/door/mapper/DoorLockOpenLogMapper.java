package com.ruoyi.door.mapper;

import com.ruoyi.door.domain.DoorLockOpenLog;

import java.util.List;

/**
 * 卡片开锁Mapper接口
 * card Mapper
 */
public interface DoorLockOpenLogMapper {
    List<DoorLockOpenLog> getAllLog();

    int insertOpenDoorLockLog(DoorLockOpenLog doorLockOpenLog);
}
