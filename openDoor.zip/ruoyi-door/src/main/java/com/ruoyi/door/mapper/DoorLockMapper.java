package com.ruoyi.door.mapper;

import com.ruoyi.door.domain.DoorOpenCard;

import java.util.List;

/**
 * 卡片开锁Mapper接口
 * card Mapper
 */
public interface DoorLockMapper {
    /**
     * 查询锁zhuangtai
     * Query Lock Status
     */
    public int selectDoorLockStatus();

    void updateDoorLockStatus(Integer lockStatus);
}
