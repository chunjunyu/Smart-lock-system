package com.ruoyi.door.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 指纹开锁对象 door_open_fingerprint
 */
public class DoorOpenFingerprint extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private Long id;

    /** 密码
     * password */
    @Excel(name = "密码")
    private String pass;

    /**
     * 开锁方式（1：卡片开锁，2：指纹开锁）
     * Unlocking method (1: card unlocking, 2: fingerprint unlocking)
     */
    private Integer openType;

    /** 创建时间
     * Creation time */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
    private String dataTime;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setPass(String pass)
    {
        this.pass = pass;
    }

    public String getPass()
    {
        return pass;
    }
    public void setDataTime(String dataTime)
    {
        this.dataTime = dataTime;
    }

    public String getDataTime()
    {
        return dataTime;
    }

    public Integer getOpenType() {
        return openType;
    }

    public void setOpenType(Integer openType) {
        this.openType = openType;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("pass", getPass())
            .append("dataTime", getDataTime())
            .toString();
    }
}
