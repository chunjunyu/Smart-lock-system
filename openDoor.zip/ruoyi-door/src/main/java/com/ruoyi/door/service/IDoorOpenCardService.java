package com.ruoyi.door.service;

import java.util.List;

import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.door.domain.DoorOpenCard;

/**
 * 卡片开锁Service接口
 * Card Unlock Service Interface
 * @date 2024-08-05
 */
public interface IDoorOpenCardService 
{
    /**
     * 查询卡片开锁
     * Enquiry card unlocking
     * 
     * @param id 卡片开锁主键
     * @return 卡片开锁
     */
    public DoorOpenCard selectDoorOpenCardById(Long id);

    /**
     * 查询卡片开锁列表
     * Query Card Unlocking List
     * 
     * @param doorOpenCard 卡片开锁
     * @return 卡片开锁集合
     */
    public List<DoorOpenCard> selectDoorOpenCardList(DoorOpenCard doorOpenCard);

    /**
     * 新增卡片开锁
     * New card unlocking
     * 
     * @param doorOpenCard 卡片开锁
     * @return 结果
     */
    public AjaxResult insertDoorOpenCard(DoorOpenCard doorOpenCard);

    /**
     * 修改卡片开锁
     * Modify card unlocking
     * 
     * @param doorOpenCard 卡片开锁
     * @return 结果
     */
    public int updateDoorOpenCard(DoorOpenCard doorOpenCard);

    /**
     * 批量删除卡片开锁
     * Batch Delete Card Unlocking
     * 
     * @param ids 需要删除的卡片开锁主键集合
     * @return 结果
     */
    public int deleteDoorOpenCardByIds(Long[] ids);

    /**
     * 删除卡片开锁信息
     * Delete card unlocking information
     *
     * @param id 卡片开锁主键
     * @return 结果
     */
    public int deleteDoorOpenCardById(Long id);
}
