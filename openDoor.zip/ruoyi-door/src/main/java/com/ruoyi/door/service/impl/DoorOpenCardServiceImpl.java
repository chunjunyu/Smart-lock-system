package com.ruoyi.door.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.door.domain.DoorLockOpenLog;
import com.ruoyi.door.service.DoorLockOpenLogService;
import com.ruoyi.door.service.DoorLockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.door.mapper.DoorOpenCardMapper;
import com.ruoyi.door.domain.DoorOpenCard;
import com.ruoyi.door.service.IDoorOpenCardService;

import javax.annotation.Resource;

/**
 * 卡片开锁Service业务层处理
 * Card Unlocking Service Business Layer Processing
 * @date 2024-08-05
 */
@Service
public class DoorOpenCardServiceImpl implements IDoorOpenCardService 
{
    @Autowired
    private DoorOpenCardMapper doorOpenCardMapper;

    @Resource
    private DoorLockService doorLockService;

    @Resource
    private DoorLockOpenLogService doorLockOpenLogService;

    /**
     * 查询卡片开锁
     * Enquiry card unlocking
     *
     * 
     * @param id 卡片开锁主键
     * @return 卡片开锁
     */
    @Override
    public DoorOpenCard selectDoorOpenCardById(Long id)
    {
        return doorOpenCardMapper.selectDoorOpenCardById(id);
    }

    /**
     * 查询卡片开锁列表
     * Query Card Unlocking List
     * 
     * @param doorOpenCard 卡片开锁
     * @return 卡片开锁
     */
    @Override
    public List<DoorOpenCard> selectDoorOpenCardList(DoorOpenCard doorOpenCard)
    {
        return doorOpenCardMapper.selectDoorOpenCardList(doorOpenCard);
    }

    /**
     * 新增卡片开锁
     * New card unlocking
     * 
     * @param doorOpenCard 卡片开锁
     * @return 结果
     */
    @Override
    public AjaxResult insertDoorOpenCard(DoorOpenCard doorOpenCard)
    {

        System.out.println("doorOpenFingerprint.toString()===>" + doorOpenCard.toString());
        LocalDateTime now = LocalDateTime.now();
        System.out.println("当前时间: " + now);

        // 格式化时间
        // Formatting time
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDate = now.format(formatter);
        System.out.println("格式化后的时间: " + formattedDate);


        doorOpenCard.setDataTime(formattedDate);

        // 添加判断逻辑：检查是否存在相同的 pass
        // Add judgement logic: check if the same pass exists
        DoorOpenCard existingCard = doorOpenCardMapper.selectDoorOpenCardByPass(doorOpenCard.getPass());
        if (existingCard != null) {
            return AjaxResult.error("This card information already exists");
        }

        doorOpenCardMapper.insertDoorOpenCard(doorOpenCard);

        return AjaxResult.success("Add Card Information Successfully");
    }

    /**
     * 修改卡片开锁
     * Modify card unlocking
     * 
     * @param doorOpenCard 卡片开锁
     * @return 结果
     */
    @Override
    public int updateDoorOpenCard(DoorOpenCard doorOpenCard)
    {
        return doorOpenCardMapper.updateDoorOpenCard(doorOpenCard);
    }

    /**
     * 批量删除卡片开锁
     * Batch Delete Card Unlocking
     * 
     * @param ids 需要删除的卡片开锁主键
     * @return 结果
     */
    @Override
    public int deleteDoorOpenCardByIds(Long[] ids)
    {
        return doorOpenCardMapper.deleteDoorOpenCardByIds(ids);
    }

    /**
     * 删除卡片开锁信息
     * Delete card unlocking information
     * 
     * @param id 卡片开锁主键
     * @return 结果
     */
    @Override
    public int deleteDoorOpenCardById(Long id)
    {
        return doorOpenCardMapper.deleteDoorOpenCardById(id);
    }
}
