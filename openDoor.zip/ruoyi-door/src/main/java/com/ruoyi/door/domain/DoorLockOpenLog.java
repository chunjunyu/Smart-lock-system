package com.ruoyi.door.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruoyi.common.core.domain.BaseEntity;

import java.io.Serializable;

/**
 * @date 2024/8/19
 */
public class DoorLockOpenLog extends BaseEntity {
    private static final long serialVersionUID = 1L;

    private Integer id;
    /**
     * 开锁方式，Card-卡片， Fingerprint-指纹
     * Unlock method, Card - card, Fingerprint - fingerprint
     */
    private String openLockMethod;
    /**
     * success: 成功， fail: 失败
     * success: success, fail: failure
     */
    private String result;
    /**
     * 开锁时间
     * Unlock time
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private String logTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOpenLockMethod() {
        return openLockMethod;
    }

    public void setOpenLockMethod(String openLockMethod) {
        this.openLockMethod = openLockMethod;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getLogTime() {
        return logTime;
    }

    public void setLogTime(String logTime) {
        this.logTime = logTime;
    }

    public DoorLockOpenLog(Integer id, String openLockMethod, String result, String logTime) {
        this.id = id;
        this.openLockMethod = openLockMethod;
        this.result = result;
        this.logTime = logTime;
    }

    public DoorLockOpenLog(String openLockMethod, String result, String logTime) {
        this.openLockMethod = openLockMethod;
        this.result = result;
        this.logTime = logTime;
    }

    public DoorLockOpenLog() {
    }
}
