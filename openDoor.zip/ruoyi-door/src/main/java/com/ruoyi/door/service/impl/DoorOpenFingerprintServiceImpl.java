package com.ruoyi.door.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.door.domain.DoorLockOpenLog;
import com.ruoyi.door.domain.DoorOpenCard;
import com.ruoyi.door.service.DoorLockOpenLogService;
import com.ruoyi.door.service.DoorLockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.door.mapper.DoorOpenFingerprintMapper;
import com.ruoyi.door.domain.DoorOpenFingerprint;
import com.ruoyi.door.service.IDoorOpenFingerprintService;

import javax.annotation.Resource;

/**
 * 指纹开锁Service业务层处理
 * Fingerprint Unlocking Service Business Layer Processing
 * @date 2024-08-05
 */
@Service
public class DoorOpenFingerprintServiceImpl implements IDoorOpenFingerprintService 
{
    @Autowired
    private DoorOpenFingerprintMapper doorOpenFingerprintMapper;

    @Resource
    private DoorLockService doorLockService;

    @Resource
    private DoorLockOpenLogService doorLockOpenLogService;

    /**
     * 查询指纹开锁
     * Enquiry on Fingerprint Unlocking
     * 
     * @param id 指纹开锁主键
     * @return 指纹开锁
     */
    @Override
    public DoorOpenFingerprint selectDoorOpenFingerprintById(Long id)
    {
        return doorOpenFingerprintMapper.selectDoorOpenFingerprintById(id);
    }

    /**
     * 查询指纹开锁列表
     * Check Fingerprint Unlocking List
     * 
     * @param doorOpenFingerprint 指纹开锁
     * @return 指纹开锁
     */
    @Override
    public List<DoorOpenFingerprint> selectDoorOpenFingerprintList(DoorOpenFingerprint doorOpenFingerprint)
    {
        return doorOpenFingerprintMapper.selectDoorOpenFingerprintList(doorOpenFingerprint);
    }

    /**
     * 新增指纹开锁
     * Add Fingerprint Unlocking
     * 
     * @param doorOpenFingerprint 指纹开锁
     * @return 结果
     */
    @Override
    public AjaxResult insertDoorOpenFingerprint(DoorOpenFingerprint doorOpenFingerprint) {

        System.out.println("doorOpenFingerprint.toString()===>" + doorOpenFingerprint.toString());
        LocalDateTime now = LocalDateTime.now();
        System.out.println("当前时间: " + now);

        // 格式化时间
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDate = now.format(formatter);
        System.out.println("格式化后的时间: " + formattedDate);


        doorOpenFingerprint.setDataTime(formattedDate);


        // 添加判断逻辑：检查是否存在相同的 pass
        DoorOpenFingerprint existingFingerprint = doorOpenFingerprintMapper.selectDoorOpenFingerprintByPass(doorOpenFingerprint.getPass());
        if (existingFingerprint != null) {
            return AjaxResult.error("This fingerprint information already exists");
        }

        doorOpenFingerprintMapper.insertDoorOpenFingerprint(doorOpenFingerprint);
        return AjaxResult.success("Fingerprint information added successfully");
    }

    /**
     * 修改指纹开锁
     * Modify Fingerprint Unlocking
     * 
     * @param doorOpenFingerprint 指纹开锁
     * @return 结果
     */
    @Override
    public int updateDoorOpenFingerprint(DoorOpenFingerprint doorOpenFingerprint)
    {
        return doorOpenFingerprintMapper.updateDoorOpenFingerprint(doorOpenFingerprint);
    }

    /**
     * 批量删除指纹开锁
     * Batch Delete Fingerprint Unlocking
     * 
     * @param ids 需要删除的指纹开锁主键
     * @return 结果
     */
    @Override
    public int deleteDoorOpenFingerprintByIds(Long[] ids)
    {
        return doorOpenFingerprintMapper.deleteDoorOpenFingerprintByIds(ids);
    }

    /**
     * 删除指纹开锁信息
     * Delete fingerprint unlocking information
     * 
     * @param id 指纹开锁主键
     * @return 结果
     */
    @Override
    public int deleteDoorOpenFingerprintById(Long id)
    {
        return doorOpenFingerprintMapper.deleteDoorOpenFingerprintById(id);
    }
}
