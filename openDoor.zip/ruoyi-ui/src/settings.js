module.exports = {
  /**
   * Sidebar theme: 'theme-dark' for dark theme, 'theme-light' for light theme
   */
  sideTheme: 'theme-dark',

  /**
   * Whether to show the system layout settings
   */
  showSettings: false,

  /**
   * Whether to display the top navigation
   */
  topNav: false,

  /**
   * Whether to display tagsView
   */
  tagsView: true,

  /**
   * Whether to fix the header
   */
  fixedHeader: false,

  /**
   * Whether to display the logo
   */
  sidebarLogo: true,

  /**
   * Whether to display a dynamic title
   */
  dynamicTitle: false,

  /**
   * @type {string | array} 'production' | ['production', 'development']
   * @description Determines where to show the error logs component.
   * The default is to use it only in the production environment.
   * If you want to use it in development as well, you can pass ['production', 'development']
   */
  errorLog: 'production'
}
