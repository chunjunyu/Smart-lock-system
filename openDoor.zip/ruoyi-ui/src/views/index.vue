<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">

      <el-form-item>
        <el-button type="primary" icon="el-icon-unlock" size="medium" @click="openSaveModel">Enable Storage Mode</el-button>
        <el-button type="info" icon="el-icon-lock" size="medium" @click="openValidModel">Enable Authentication Mode</el-button>
        <el-button icon="el-icon-refresh" size="medium" @click="getList">Refresh</el-button>
      </el-form-item>
    </el-form>

    <el-table v-loading="loading" :data="cardList">
      <el-table-column label="ID" align="center" prop="id" />
      <el-table-column label="Unlock Method" align="center" prop="openLockMethod" />
      <el-table-column label="Success" align="center" prop="result" />
      <el-table-column label="Unlock Time" align="center" prop="logTime" width="180">
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- Add or Edit Card Unlock Dialog -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="Password" prop="pass">
          <el-input v-model="form.pass" placeholder="Please enter the password" />
        </el-form-item>
        <el-form-item label="Creation Time" prop="dataTime">
          <el-date-picker clearable
                          v-model="form.dataTime"
                          type="date"
                          value-format="yyyy-MM-dd"
                          placeholder="Please select the creation time">
          </el-date-picker>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">Confirm</el-button>
        <el-button @click="cancel">Cancel</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listCard, getCard, delCard, addCard, updateCard } from "@/api/door/card";
import { lockLockApi, getLockStatusApi, getLockOpenLogApi } from "@/api/door/lock";

export default {
  name: "DoorIndex",
  data() {
    return {
      // Loading indicator
      loading: false,
      // Selected IDs array
      ids: [],
      // Single selection disabled
      single: true,
      // Multiple selection disabled
      multiple: true,
      // Show search conditions
      showSearch: true,
      // Total number of records
      total: 0,
      // Card unlock table data
      cardList: [],
      // Dialog title
      title: "",
      // Dialog visibility
      open: false,
      // Query parameters
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        pass: null,
        dataTime: null
      },
      validModel: {
        status: 1
      },
      saveModel: {
        status: 0
      },
      // Form parameters
      form: {},
      // Form validation rules
      rules: {},
    };
  },
  created() {
    this.getList();
  },
  methods: {
    /** Fetch unlock records */
    getList() {
      this.loading = true;
      getLockOpenLogApi(this.queryParams).then(response => {
        this.cardList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    /**
     * Check lock status
     */
    getLockStatus() {
      getLockStatusApi().then(response => {
        if (response.data === 1) {
          this.$message({
            type: 'success',
            message: 'Unlocking successful!'
          });
        } else {
          this.$message({
            type: 'error',
            message: 'Unlocking failed!'
          });
        }
      });
    },
    /**
     * Enable authentication mode
     */
    openValidModel() {
      lockLockApi(this.validModel).then(response => {
        if (response.code === 200) {
          this.$message({
            type: 'success',
            message: 'Switched to authentication mode!'
          });
        } else {
          this.$message({
            type: 'error',
            message: response.msg
          });
        }
      });
    },
    /**
     * Enable storage mode
     */
    openSaveModel() {
      lockLockApi(this.saveModel).then(response => {
        if (response.code === 200) {
          this.$message({
            type: 'success',
            message: 'Switched to storage mode!'
          });
        } else {
          this.$message({
            type: 'error',
            message: response.msg
          });
        }
      });
    },
    /**
     * Wait for unlock confirmation dialog
     */
    waitingOpenLock() {
      this.$confirm('Waiting to unlock, has it been unlocked?', '', {
        confirmButtonText: 'Unlocked',
        cancelButtonText: 'Cancel',
        type: ''
      }).then(() => {

      }).catch(() => {
        this.$message({
          type: 'info',
          message: 'Unlocking cancelled'
        });
      });
    },
    /** Submit button */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != null) {
            updateCard(this.form).then(response => {
              this.$modal.msgSuccess("Modified successfully");
              this.open = false;
              this.getList();
            });
          } else {
            addCard(this.form).then(response => {
              if (response === -1) {
                this.$modal.msgError("This password already exists, please change it");
              } else {
                this.$modal.msgSuccess("Added successfully");
                this.open = false;
                this.getList();
              }
            });
          }
        }
      });
    },
    /** Delete button operation */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$modal.confirm('Are you sure you want to delete the card unlock record with ID "' + ids + '"?').then(function() {
        return delCard(ids);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("Deleted successfully");
      }).catch(() => {});
    },

    /** Export button operation */
    handleExport() {
      this.download('door/card/export', {
        ...this.queryParams
      }, `card_${new Date().getTime()}.xlsx`)
    }
  }
};
</script>
