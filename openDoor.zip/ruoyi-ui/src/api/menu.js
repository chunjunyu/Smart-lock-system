import request from '@/utils/request'

// 获取路由
// Get routes
export const getRouters = () => {
  return request({
    url: '/getRouters', // 请求的API地址 // API endpoint
    method: 'get' // HTTP请求方法 // HTTP request method
  })
}
