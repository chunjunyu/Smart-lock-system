import request from '@/utils/request'

// 查询卡片开锁列表
// Query the list of card unlocks
export function listCard(query) {
  return request({
    url: '/door/card/list',
    method: 'get',
    params: query
  })
}

// 查询卡片开锁详细
// Query card unlock details
export function getCard(id) {
  return request({
    url: '/door/card/' + id,
    method: 'get'
  })
}

// 新增卡片开锁
// Add a new card unlock
export function addCard(data) {
  return request({
    url: '/door/card',
    method: 'post',
    data: data
  })
}

// 修改卡片开锁
// Update card unlock
export function updateCard(data) {
  return request({
    url: '/door/card',
    method: 'put',
    data: data
  })
}

// 删除卡片开锁
// Delete card unlock
export function delCard(id) {
  return request({
    url: '/door/card/' + id,
    method: 'delete'
  })
}
