import request from '@/utils/request'

// 查询指纹开锁列表
// Query the list of fingerprint unlocks
export function listFingerprint(query) {
  return request({
    url: '/door/fingerprint/list',
    method: 'get',
    params: query
  })
}

// 查询指纹开锁详细
// Query fingerprint unlock details
export function getFingerprint(id) {
  return request({
    url: '/door/fingerprint/' + id,
    method: 'get'
  })
}

// 新增指纹开锁
// Add a new fingerprint unlock
export function addFingerprint(data) {
  return request({
    url: '/door/fingerprint',
    method: 'post',
    data: data
  })
}

// 修改指纹开锁
// Update fingerprint unlock
export function updateFingerprint(data) {
  return request({
    url: '/door/fingerprint',
    method: 'put',
    data: data
  })
}

// 删除指纹开锁
// Delete fingerprint unlock
export function delFingerprint(id) {
  return request({
    url: '/door/fingerprint/' + id,
    method: 'delete'
  })
}
