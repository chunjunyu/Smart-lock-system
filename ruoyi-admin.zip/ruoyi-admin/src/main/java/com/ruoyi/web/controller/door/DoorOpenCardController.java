package com.ruoyi.web.controller.door;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.door.domain.DoorOpenCard;
import com.ruoyi.door.domain.DoorOpenFingerprint;
import com.ruoyi.door.service.DoorLockService;
import com.ruoyi.door.service.IDoorOpenCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import java.util.Map;

/**
 * 卡片开锁Controller
 * Card Unlock Controller
 */
@RestController
@RequestMapping("/door/card")
public class DoorOpenCardController extends BaseController
{
    @Autowired
    private IDoorOpenCardService doorOpenCardService;
    /**
     * 查询卡片开锁列表
     * Query Card Unlocking List
     */
//    @PreAuthorize("@ss.hasPermi('door:card:list')")
    @GetMapping("/list")
    public TableDataInfo list(DoorOpenCard doorOpenCard)
    {
        startPage();
        List<DoorOpenCard> list = doorOpenCardService.selectDoorOpenCardList(doorOpenCard);
        return getDataTable(list);
    }

    /**
     * 导出卡片开锁列表
     * Exporting a list of card openers
     */
//    @PreAuthorize("@ss.hasPermi('door:card:export')")
    @Log(title = "卡片开锁", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, DoorOpenCard doorOpenCard)
    {
        List<DoorOpenCard> list = doorOpenCardService.selectDoorOpenCardList(doorOpenCard);
        ExcelUtil<DoorOpenCard> util = new ExcelUtil<DoorOpenCard>(DoorOpenCard.class);
        util.exportExcel(response, list, "卡片开锁数据");
    }

    /**
     * 获取卡片开锁详细信息
     * Get card unlocking details
     */
//    @PreAuthorize("@ss.hasPermi('door:card:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {

        return success(doorOpenCardService.selectDoorOpenCardById(id));
    }

    /**
     * 新增卡片开锁
     * New card unlocking
     */
//    @PreAuthorize("@ss.hasPermi('door:card:add')")
    @Log(title = "卡片开锁", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody DoorOpenCard doorOpenCard)
    {
        return doorOpenCardService.insertDoorOpenCard(doorOpenCard);
    }

    /**
     * 修改卡片开锁
     * Modify card unlocking
     */
//    @PreAuthorize("@ss.hasPermi('door:card:edit')")
    @Log(title = "卡片开锁", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody DoorOpenCard doorOpenCard)
    {
        return toAjax(doorOpenCardService.updateDoorOpenCard(doorOpenCard));
    }

    /**
     * 删除卡片开锁
     * Delete Card Unlocking
     */
//    @PreAuthorize("@ss.hasPermi('door:card:remove')")
    @Log(title = "卡片开锁", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(doorOpenCardService.deleteDoorOpenCardByIds(ids));
    }

    @PostMapping("/prod-api/door/card/getOne")
    @ResponseBody
    public String handleCardRequest(@RequestBody String pass) {

        DoorOpenCard doorOpenCard = null;
        doorOpenCard.setPass(pass);
        List<DoorOpenCard> list = doorOpenCardService.selectDoorOpenCardList(doorOpenCard);

        if (list.isEmpty()){
            return "Failed to unlock";
        }else
        {
            return "Successful unlocking.";
        }
    }
}
