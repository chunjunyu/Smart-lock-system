package com.ruoyi.web.controller.door;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.door.domain.DoorOpenFingerprint;
import com.ruoyi.door.service.DoorLockService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@RequestMapping("/door/lock")
public class DoorLockController extends BaseController {

    @Resource
    private DoorLockService doorLockService;

    @GetMapping("/status")
    public AjaxResult getLockStatus(){
        return AjaxResult.success(doorLockService.getLockStatus());
    }

    /**
     * 调整模式 0-存储数据， 1-验证数据
     * Adjustment mode 0-store data, 1-verify data
     */
    @PostMapping("/lock")
    public AjaxResult lockLock(@RequestParam Integer status){
        doorLockService.updateDoorLockStatus(status);
        return AjaxResult.success();
    }

    @PostMapping("/openByPass")
    public AjaxResult openLockByPass(@RequestBody DoorOpenFingerprint doorOpenFingerprint){
        return doorLockService.openLockByPass(doorOpenFingerprint);
    }
}
