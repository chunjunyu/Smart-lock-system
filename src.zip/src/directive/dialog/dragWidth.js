/**
 * v-dialogDragWidth 可拖动弹窗宽度（右侧边）
 * v-dialogDragWidth Draggable Dialog Width (Right Side)
 * Copyright (c) 2019 ruoyi
 */

export default {
  bind(el) {
    const dragDom = el.querySelector('.el-dialog');
    const lineEl = document.createElement('div');
    lineEl.style = 'width: 5px; background: inherit; height: 80%; position: absolute; right: 0; top: 0; bottom: 0; margin: auto; z-index: 1; cursor: w-resize;';
    lineEl.addEventListener('mousedown',
      function (e) {
        // 鼠标按下，计算当前元素距离可视区的距离
        // When the mouse is pressed, calculate the distance from the current element to the visible area
        const disX = e.clientX - el.offsetLeft;
        // 当前宽度
        // Current width
        const curWidth = dragDom.offsetWidth;
        document.onmousemove = function (e) {
          e.preventDefault(); // 移动时禁用默认事件
          // Prevent default behavior during movement
          // 通过事件委托，计算移动的距离
          // Calculate the moving distance by event delegation
          const l = e.clientX - disX;
          dragDom.style.width = `${curWidth + l}px`;
        };
        document.onmouseup = function (e) {
          document.onmousemove = null;
          document.onmouseup = null;
        };
      }, false);
    dragDom.appendChild(lineEl);
  }
}
