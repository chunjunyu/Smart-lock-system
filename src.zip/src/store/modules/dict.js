const state = {
  dict: new Array() // Array to store dictionaries
}

const mutations = {
  SET_DICT: (state, { key, value }) => {
    if (key !== null && key !== "") {
      state.dict.push({
        key: key,
        value: value
      })
    }
  },
  REMOVE_DICT: (state, key) => {
    try {
      for (let i = 0; i < state.dict.length; i++) {
        if (state.dict[i].key == key) {
          state.dict.splice(i, 1)
          return true
        }
      }
    } catch (e) {
      // Handle any potential errors
    }
  },
  CLEAN_DICT: (state) => {
    state.dict = new Array() // Clear the dictionary array
  }
}

const actions = {
  // 设置字典
  // Set a dictionary
  setDict({ commit }, data) {
    commit('SET_DICT', data)
  },
  // 删除字典
  // Remove a dictionary
  removeDict({ commit }, key) {
    commit('REMOVE_DICT', key)
  },
  // 清空字典
  // Clean all dictionaries
  cleanDict({ commit }) {
    commit('CLEAN_DICT')
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
