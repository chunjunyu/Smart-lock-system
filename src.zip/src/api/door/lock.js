import request from '@/utils/request'

// 查询开锁状态
// Query lock status
export function getLockStatusApi() {
  return request({
    url: '/door/lock/status',
    method: 'get'
  })
}

// 关锁
// Lock the door
export function lockLockApi(query) {
  return request({
    url: '/door/lock/lock',
    method: 'post',
    params: query
  })
}

// 查询开锁日志
// Query lock opening logs
export function getLockOpenLogApi() {
  return request({
    url: '/door/lock/open/log/list',
    method: 'get'
  })
}
