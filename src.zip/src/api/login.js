import request from '@/utils/request'

// 登录方法
// Login method
export function login(username, password, code, uuid) {
  const data = {
    username,
    password,
    code,
    uuid
  }
  return request({
    url: '/login',
    headers: {
      isToken: false, // 不携带token // Do not carry token
      repeatSubmit: false // 防止重复提交 // Prevent repeated submissions
    },
    method: 'post',
    data: data
  })
}

// 注册方法
// Registration method
export function register(data) {
  return request({
    url: '/register',
    headers: {
      isToken: false // 不携带token // Do not carry token
    },
    method: 'post',
    data: data
  })
}

// 获取用户详细信息
// Get user details
export function getInfo() {
  return request({
    url: '/getInfo',
    method: 'get'
  })
}

// 退出方法
// Logout method
export function logout() {
  return request({
    url: '/logout',
    method: 'post'
  })
}

// 获取验证码
// Get captcha image
export function getCodeImg() {
  return request({
    url: '/captchaImage',
    headers: {
      isToken: false // 不携带token // Do not carry token
    },
    method: 'get',
    timeout: 20000 // 设置请求超时时间 // Set request timeout
  })
}
