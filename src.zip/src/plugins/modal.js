import { Message, MessageBox, Notification, Loading } from 'element-ui'

let loadingInstance;

export default {
  // 消息提示
  // Message prompt
  msg(content) {
    Message.info(content)
  },
  // 错误消息
  // Error message
  msgError(content) {
    Message.error(content)
  },
  // 成功消息
  // Success message
  msgSuccess(content) {
    Message.success(content)
  },
  // 警告消息
  // Warning message
  msgWarning(content) {
    Message.warning(content)
  },
  // 弹出提示
  // Pop-up alert
  alert(content) {
    MessageBox.alert(content, "系统提示") // "System Prompt"
  },
  // 错误提示
  // Error alert
  alertError(content) {
    MessageBox.alert(content, "系统提示", { type: 'error' }) // "System Prompt"
  },
  // 成功提示
  // Success alert
  alertSuccess(content) {
    MessageBox.alert(content, "系统提示", { type: 'success' }) // "System Prompt"
  },
  // 警告提示
  // Warning alert
  alertWarning(content) {
    MessageBox.alert(content, "系统提示", { type: 'warning' }) // "System Prompt"
  },
  // 通知提示
  // Notification prompt
  notify(content) {
    Notification.info(content)
  },
  // 错误通知
  // Error notification
  notifyError(content) {
    Notification.error(content);
  },
  // 成功通知
  // Success notification
  notifySuccess(content) {
    Notification.success(content)
  },
  // 警告通知
  // Warning notification
  notifyWarning(content) {
    Notification.warning(content)
  },
  // 确认窗体
  // Confirmation dialog
  confirm(content) {
    return MessageBox.confirm(content, "系统提示", {
      confirmButtonText: '确定', // "Confirm"
      cancelButtonText: '取消',  // "Cancel"
      type: "warning",
    })
  },
  // 提交内容
  // Prompt dialog
  prompt(content) {
    return MessageBox.prompt(content, "系统提示", {
      confirmButtonText: '确定', // "Confirm"
      cancelButtonText: '取消',  // "Cancel"
      type: "warning",
    })
  },
  // 打开遮罩层
  // Open loading overlay
  loading(content) {
    loadingInstance = Loading.service({
      lock: true,
      text: content,
      spinner: "el-icon-loading",
      background: "rgba(0, 0, 0, 0.7)",
    })
  },
  // 关闭遮罩层
  // Close loading overlay
  closeLoading() {
    loadingInstance.close();
  }
}
