package com.ruoyi.door.service;

import com.ruoyi.door.domain.DoorLockOpenLog;
import com.ruoyi.door.mapper.DoorLockOpenLogMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @date 2024/8/20
 */
@Service
public class DoorLockOpenLogService {
    @Resource
    private DoorLockOpenLogMapper doorLockOpenLogMapper;

    public List<DoorLockOpenLog> getAllLog(){
        return doorLockOpenLogMapper.getAllLog();
    }

    public void insertDoorLockOpenLog(DoorLockOpenLog doorLockOpenLog){
        doorLockOpenLogMapper.insertOpenDoorLockLog(doorLockOpenLog);
    }
}
