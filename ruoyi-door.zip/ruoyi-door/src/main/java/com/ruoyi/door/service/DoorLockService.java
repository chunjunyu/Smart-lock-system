package com.ruoyi.door.service;

import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.door.domain.DoorLockOpenLog;
import com.ruoyi.door.domain.DoorOpenCard;
import com.ruoyi.door.domain.DoorOpenFingerprint;
import com.ruoyi.door.mapper.DoorLockMapper;
import com.ruoyi.door.mapper.DoorOpenCardMapper;
import com.ruoyi.door.mapper.DoorOpenFingerprintMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

@Service
public class DoorLockService {

    @Resource
    private DoorLockMapper doorLockMapper;

    @Resource
    private IDoorOpenCardService doorOpenCardService;

    @Resource
    private IDoorOpenFingerprintService doorOpenFingerprintService;

    @Resource
    private DoorLockOpenLogService doorLockOpenLogService;

    @Resource
    private DoorOpenCardMapper doorOpenCardMapper;

    @Resource
    private DoorOpenFingerprintMapper doorOpenFingerprintMapper;

    public int getLockStatus(){
        return doorLockMapper.selectDoorLockStatus();
    }

    public void updateDoorLockStatus(Integer lockStatus){
        doorLockMapper.updateDoorLockStatus(lockStatus);
    }

    public AjaxResult openLockByPass(DoorOpenFingerprint param) {
        if (Objects.isNull(param) || StringUtils.isEmpty(param.getPass())){
            return AjaxResult.error("Password cannot be empty");
        }

        if (Objects.isNull(param.getOpenType())){
            return AjaxResult.error("The unlocking method cannot be null");
        }
        boolean openLockByCard = Objects.equals(1, param.getOpenType());
        boolean openLockByFingerprint = Objects.equals(2, param.getOpenType());
        // 0-存储数据， 1-验证数据
        int lockStatus = this.getLockStatus();

        if (lockStatus == 0){
            return savePass(param, openLockByCard, openLockByFingerprint);
        }else{
            return validPass(param, openLockByCard, openLockByFingerprint);
        }
    }

    private AjaxResult validPass(DoorOpenFingerprint param, boolean openLockByCard, boolean openLockByFingerprint) {
        if (openLockByCard){
            return openLockByCard(param);
        }

        if (openLockByFingerprint){
            return openLockByFingerprint(param);
        }
        return AjaxResult.error("Wrong unlocking method, only support card unlocking or fingerprint unlocking.");
    }

    private AjaxResult savePass(DoorOpenFingerprint param, boolean openLockByCard, boolean openLockByFingerprint) {
        if (openLockByCard){
            DoorOpenCard doorOpenCard = new DoorOpenCard();
            doorOpenCard.setPass(param.getPass());
            return doorOpenCardService.insertDoorOpenCard(doorOpenCard);
        }

        if (openLockByFingerprint){
            DoorOpenFingerprint doorOpenFingerprint = new DoorOpenFingerprint();
            doorOpenFingerprint.setPass(param.getPass());
            return doorOpenFingerprintService.insertDoorOpenFingerprint(doorOpenFingerprint);
        }

        return AjaxResult.error("Add unlock information error, only support card or fingerprint information.");
    }

    private AjaxResult openLockByCard(DoorOpenFingerprint param) {
        DoorOpenCard doorOpenCard = doorOpenCardMapper.selectDoorOpenCardByPass(param.getPass());
        if (doorOpenCard != null){
            // 开锁成功增加一条记录
            doorLockOpenLogService.insertDoorLockOpenLog(new DoorLockOpenLog("Card", "success", getOpenLockTime()));
            return AjaxResult.error(1, "Successful unlocking");
        }else{
            // 开锁失败增加一条记录
            doorLockOpenLogService.insertDoorLockOpenLog(new DoorLockOpenLog("Card", "fail", getOpenLockTime()));
            return AjaxResult.error(0, "Failed to unlock");
        }
    }

    private AjaxResult openLockByFingerprint(DoorOpenFingerprint param) {
        DoorOpenFingerprint doorOpenFingerprint = doorOpenFingerprintMapper.selectDoorOpenFingerprintByPass(param.getPass());
        if (doorOpenFingerprint != null){
            // 开锁成功增加一条记录
            doorLockOpenLogService.insertDoorLockOpenLog(new DoorLockOpenLog("Fingerprint", "success", getOpenLockTime()));
            return AjaxResult.error(1, "Successful unlocking");
        }else{
            // 开锁失败增加一条记录
            doorLockOpenLogService.insertDoorLockOpenLog(new DoorLockOpenLog("Fingerprint", "fail", getOpenLockTime()));
            return AjaxResult.error(0, "Failed to unlock");
        }
    }

    private String getOpenLockTime(){
        LocalDateTime now = LocalDateTime.now();
        // 格式化时间
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return now.format(formatter);
    }
}
