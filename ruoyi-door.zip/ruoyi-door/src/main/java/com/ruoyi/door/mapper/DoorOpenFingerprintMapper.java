package com.ruoyi.door.mapper;

import java.util.List;

import com.ruoyi.door.domain.DoorOpenCard;
import com.ruoyi.door.domain.DoorOpenFingerprint;

/**
 * 指纹开锁Mapper接口
 * Fingerprint Unlock Mapper Interface
 */
public interface DoorOpenFingerprintMapper 
{
    /**
     * 查询指纹开锁
     * Enquiry on Fingerprint Unlocking
     * 
     * @param id 指纹开锁主键
     * @return 指纹开锁
     */
    public DoorOpenFingerprint selectDoorOpenFingerprintById(Long id);

    /**
     * 查询指纹开锁列表
     * Check Fingerprint Unlocking List
     * 
     * @param doorOpenFingerprint 指纹开锁
     * @return 指纹开锁集合
     */
    public List<DoorOpenFingerprint> selectDoorOpenFingerprintList(DoorOpenFingerprint doorOpenFingerprint);

    /**
     * 新增指纹开锁
     * Add Fingerprint Unlocking
     * 
     * @param doorOpenFingerprint 指纹开锁
     * @return 结果
     */
    public int insertDoorOpenFingerprint(DoorOpenFingerprint doorOpenFingerprint);

    /**
     * 修改指纹开锁
     * Modify Fingerprint Unlocking
     * 
     * @param doorOpenFingerprint 指纹开锁
     * @return 结果
     */
    public int updateDoorOpenFingerprint(DoorOpenFingerprint doorOpenFingerprint);

    /**
     * 删除指纹开锁
     * Delete Fingerprint Unlocking
     * 
     * @param id 指纹开锁主键
     * @return 结果
     */
    public int deleteDoorOpenFingerprintById(Long id);

    /**
     * 批量删除指纹开锁
     * Batch Delete Fingerprint Unlocking
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteDoorOpenFingerprintByIds(Long[] ids);

    public DoorOpenFingerprint selectDoorOpenFingerprintByPass(String pass);
}
