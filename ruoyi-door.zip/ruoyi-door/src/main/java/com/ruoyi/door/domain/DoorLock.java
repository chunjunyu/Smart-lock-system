package com.ruoyi.door.domain;

import java.io.Serializable;

public class DoorLock implements Serializable {
    private static final long serialVersionUID = 1L;
    private Integer id;

    private Integer lockStatus;
}
